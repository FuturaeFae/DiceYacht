import Foundation
import Darwin

final class NearbyNetworking {
    static let discoveryPort: UInt16 = 45831
    static let discoverRequest = "DICEYACHT_DISCOVER_V1"
    static let discoverResponse = "DICEYACHT_HOST_V1|"
    static let maxMessageChars = 65_536

    var onEvent: ((String, [String]) -> Void)?

    private let networkQueue = DispatchQueue(label: "com.faecreative.diceyacht.nearby", qos: .userInitiated, attributes: .concurrent)
    private let lock = NSLock()
    private var tcpListenFD: Int32 = -1
    private var hostDiscoveryFD: Int32 = -1
    private var clientDiscoveryFD: Int32 = -1
    private var clientPeer: Peer?
    private var hostPeers: [String: Peer] = [:]
    private var discovered: [String: Endpoint] = [:]
    private var hostedName = "Dice Yacht Game"
    private var discoveryRunning = false
    private var generation: UInt64 = 0

    struct Endpoint {
        let address: String
        let port: UInt16
    }

    func startHost(displayName: String) {
        closeAll()
        let clean = sanitizeName(displayName)
        hostedName = clean.isEmpty ? "Dice Yacht Game" : "\(clean)'s Game"
        generation &+= 1
        let myGeneration = generation

        networkQueue.async { [weak self] in
            guard let self else { return }
            let server = socket(PF_INET, SOCK_STREAM, IPPROTO_TCP)
            guard server >= 0 else { self.emit("onNearbyError", ["Could not create nearby host socket."]); return }
            var yes: Int32 = 1
            setsockopt(server, SOL_SOCKET, SO_REUSEADDR, &yes, socklen_t(MemoryLayout<Int32>.size))

            var addr = sockaddr_in()
            addr.sin_len = UInt8(MemoryLayout<sockaddr_in>.size)
            addr.sin_family = sa_family_t(AF_INET)
            addr.sin_port = 0
            addr.sin_addr = in_addr(s_addr: INADDR_ANY.bigEndian)
            let bindResult = withUnsafePointer(to: &addr) {
                $0.withMemoryRebound(to: sockaddr.self, capacity: 1) { bind(server, $0, socklen_t(MemoryLayout<sockaddr_in>.size)) }
            }
            guard bindResult == 0, listen(server, 8) == 0 else {
                Darwin.close(server)
                self.emit("onNearbyError", ["Could not start nearby host."])
                return
            }

            var bound = sockaddr_in()
            var boundLen = socklen_t(MemoryLayout<sockaddr_in>.size)
            guard withUnsafeMutablePointer(to: &bound, { ptr in
                ptr.withMemoryRebound(to: sockaddr.self, capacity: 1) { getsockname(server, $0, &boundLen) }
            }) == 0 else {
                Darwin.close(server)
                self.emit("onNearbyError", ["Could not determine nearby host port."])
                return
            }
            let port = UInt16(bigEndian: bound.sin_port)

            self.lock.lock()
            if myGeneration != self.generation { self.lock.unlock(); Darwin.close(server); return }
            self.tcpListenFD = server
            self.lock.unlock()

            self.startHostDiscovery(port: port, generation: myGeneration)
            self.emit("onHostReady", [self.hostedName])

            while self.isCurrent(myGeneration) {
                var clientAddr = sockaddr_storage()
                var clientLen = socklen_t(MemoryLayout<sockaddr_storage>.size)
                let fd = withUnsafeMutablePointer(to: &clientAddr) {
                    $0.withMemoryRebound(to: sockaddr.self, capacity: 1) { accept(server, $0, &clientLen) }
                }
                if fd < 0 { break }
                var noDelay: Int32 = 1
                setsockopt(fd, IPPROTO_TCP, TCP_NODELAY, &noDelay, socklen_t(MemoryLayout<Int32>.size))
                let token = UUID().uuidString
                let peer = Peer(token: token, fd: fd) { [weak self] line in
                    self?.emit("onMessage", [token, line])
                } onClose: { [weak self] in
                    guard let self else { return }
                    self.lock.lock(); self.hostPeers.removeValue(forKey: token); self.lock.unlock()
                    self.emit("onPeerDisconnected", [token])
                }
                self.lock.lock(); self.hostPeers[token] = peer; self.lock.unlock()
                self.emit("onPeerConnected", [token])
                peer.start(on: self.networkQueue)
            }
        }
    }

    private func startHostDiscovery(port: UInt16, generation myGeneration: UInt64) {
        networkQueue.async { [weak self] in
            guard let self else { return }
            let fd = socket(PF_INET, SOCK_DGRAM, IPPROTO_UDP)
            guard fd >= 0 else { return }
            var yes: Int32 = 1
            setsockopt(fd, SOL_SOCKET, SO_REUSEADDR, &yes, socklen_t(MemoryLayout<Int32>.size))
            #if !targetEnvironment(simulator)
            setsockopt(fd, SOL_SOCKET, SO_REUSEPORT, &yes, socklen_t(MemoryLayout<Int32>.size))
            #endif
            var addr = sockaddr_in()
            addr.sin_len = UInt8(MemoryLayout<sockaddr_in>.size)
            addr.sin_family = sa_family_t(AF_INET)
            addr.sin_port = Self.discoveryPort.bigEndian
            addr.sin_addr = in_addr(s_addr: INADDR_ANY.bigEndian)
            let ok = withUnsafePointer(to: &addr) {
                $0.withMemoryRebound(to: sockaddr.self, capacity: 1) { bind(fd, $0, socklen_t(MemoryLayout<sockaddr_in>.size)) }
            }
            guard ok == 0 else { Darwin.close(fd); return }

            self.lock.lock()
            if myGeneration != self.generation { self.lock.unlock(); Darwin.close(fd); return }
            self.hostDiscoveryFD = fd
            self.lock.unlock()

            var buffer = [UInt8](repeating: 0, count: 1024)
            while self.isCurrent(myGeneration) {
                var source = sockaddr_in()
                var sourceLen = socklen_t(MemoryLayout<sockaddr_in>.size)
                let count = buffer.withUnsafeMutableBytes { raw in
                    withUnsafeMutablePointer(to: &source) { src in
                        src.withMemoryRebound(to: sockaddr.self, capacity: 1) {
                            recvfrom(fd, raw.baseAddress, raw.count, 0, $0, &sourceLen)
                        }
                    }
                }
                if count <= 0 { break }
                let request = String(bytes: buffer[0..<count], encoding: .utf8) ?? ""
                guard request == Self.discoverRequest else { continue }
                let response = "\(Self.discoverResponse)\(port)|\(self.sanitizeName(self.hostedName))"
                response.withCString { ptr in
                    withUnsafePointer(to: &source) { src in
                        src.withMemoryRebound(to: sockaddr.self, capacity: 1) {
                            _ = sendto(fd, ptr, strlen(ptr), 0, $0, sourceLen)
                        }
                    }
                }
            }
        }
    }

    func startDiscovery() {
        stopDiscovery()
        lock.lock(); discovered.removeAll(); discoveryRunning = true; generation &+= 1; let myGeneration = generation; lock.unlock()
        emit("onDiscoveryStarted", [])

        networkQueue.async { [weak self] in
            guard let self else { return }
            let fd = socket(PF_INET, SOCK_DGRAM, IPPROTO_UDP)
            guard fd >= 0 else { self.emit("onNearbyError", ["Could not search the local network."]); return }
            var yes: Int32 = 1
            setsockopt(fd, SOL_SOCKET, SO_BROADCAST, &yes, socklen_t(MemoryLayout<Int32>.size))
            setsockopt(fd, SOL_SOCKET, SO_REUSEADDR, &yes, socklen_t(MemoryLayout<Int32>.size))
            var bindAddr = sockaddr_in()
            bindAddr.sin_len = UInt8(MemoryLayout<sockaddr_in>.size)
            bindAddr.sin_family = sa_family_t(AF_INET)
            bindAddr.sin_port = 0
            bindAddr.sin_addr = in_addr(s_addr: INADDR_ANY.bigEndian)
            let bound = withUnsafePointer(to: &bindAddr) {
                $0.withMemoryRebound(to: sockaddr.self, capacity: 1) { bind(fd, $0, socklen_t(MemoryLayout<sockaddr_in>.size)) }
            }
            guard bound == 0 else { Darwin.close(fd); self.emit("onNearbyError", ["Could not start nearby search."]); return }
            self.lock.lock(); self.clientDiscoveryFD = fd; self.lock.unlock()

            var timeout = timeval(tv_sec: 0, tv_usec: 350_000)
            setsockopt(fd, SOL_SOCKET, SO_RCVTIMEO, &timeout, socklen_t(MemoryLayout<timeval>.size))
            var lastSend = Date.distantPast
            var buffer = [UInt8](repeating: 0, count: 1024)

            while self.discoveryIsRunning(myGeneration) {
                if Date().timeIntervalSince(lastSend) >= 0.9 {
                    self.sendDiscovery(fd: fd)
                    lastSend = Date()
                }
                var source = sockaddr_in()
                var sourceLen = socklen_t(MemoryLayout<sockaddr_in>.size)
                let count = buffer.withUnsafeMutableBytes { raw in
                    withUnsafeMutablePointer(to: &source) { src in
                        src.withMemoryRebound(to: sockaddr.self, capacity: 1) {
                            recvfrom(fd, raw.baseAddress, raw.count, 0, $0, &sourceLen)
                        }
                    }
                }
                if count <= 0 { continue }
                let text = String(bytes: buffer[0..<count], encoding: .utf8) ?? ""
                self.handleDiscovery(text: text, source: source)
            }
            Darwin.close(fd)
        }
    }

    private func sendDiscovery(fd: Int32) {
        var target = sockaddr_in()
        target.sin_len = UInt8(MemoryLayout<sockaddr_in>.size)
        target.sin_family = sa_family_t(AF_INET)
        target.sin_port = Self.discoveryPort.bigEndian
        inet_pton(AF_INET, "255.255.255.255", &target.sin_addr)
        Self.discoverRequest.withCString { ptr in
            withUnsafePointer(to: &target) { dst in
                dst.withMemoryRebound(to: sockaddr.self, capacity: 1) {
                    _ = sendto(fd, ptr, strlen(ptr), 0, $0, socklen_t(MemoryLayout<sockaddr_in>.size))
                }
            }
        }
    }

    private func handleDiscovery(text: String, source: sockaddr_in) {
        guard text.hasPrefix(Self.discoverResponse) else { return }
        let rest = String(text.dropFirst(Self.discoverResponse.count))
        guard let split = rest.firstIndex(of: "|"), let port = UInt16(rest[..<split]), port > 0 else { return }
        let name = sanitizeName(String(rest[rest.index(after: split)...]))
        var address = source.sin_addr
        var chars = [CChar](repeating: 0, count: Int(INET_ADDRSTRLEN))
        guard inet_ntop(AF_INET, &address, &chars, socklen_t(INET_ADDRSTRLEN)) != nil else { return }
        let host = String(cString: chars)
        let serviceId = "\(host):\(port)"
        lock.lock(); discovered[serviceId] = Endpoint(address: host, port: port); lock.unlock()
        emit("onServiceFound", [serviceId, name.isEmpty ? "Dice Yacht Game" : name])
    }

    func connect(serviceId: String) {
        lock.lock(); let endpoint = discovered[serviceId]; lock.unlock()
        guard let endpoint else { emit("onNearbyError", ["That nearby game is no longer available. Search again."]); return }
        stopDiscovery()
        closeClientOnly()

        networkQueue.async { [weak self] in
            guard let self else { return }
            let fd = socket(PF_INET, SOCK_STREAM, IPPROTO_TCP)
            guard fd >= 0 else { self.emit("onNearbyError", ["Could not create connection."]); return }
            var addr = sockaddr_in()
            addr.sin_len = UInt8(MemoryLayout<sockaddr_in>.size)
            addr.sin_family = sa_family_t(AF_INET)
            addr.sin_port = endpoint.port.bigEndian
            guard inet_pton(AF_INET, endpoint.address, &addr.sin_addr) == 1 else { Darwin.close(fd); return }
            let result = withUnsafePointer(to: &addr) {
                $0.withMemoryRebound(to: sockaddr.self, capacity: 1) { Darwin.connect(fd, $0, socklen_t(MemoryLayout<sockaddr_in>.size)) }
            }
            guard result == 0 else { Darwin.close(fd); self.emit("onNearbyError", ["Could not join nearby game."]); return }
            var noDelay: Int32 = 1
            setsockopt(fd, IPPROTO_TCP, TCP_NODELAY, &noDelay, socklen_t(MemoryLayout<Int32>.size))
            let peer = Peer(token: "host", fd: fd) { [weak self] line in
                self?.emit("onMessage", ["", line])
            } onClose: { [weak self] in
                self?.emit("onClientDisconnected", [])
            }
            self.lock.lock(); self.clientPeer = peer; self.lock.unlock()
            self.emit("onClientConnected", [serviceId])
            peer.start(on: self.networkQueue)
        }
    }

    func sendToHost(_ json: String) {
        lock.lock(); let peer = clientPeer; lock.unlock(); peer?.send(json)
    }

    func broadcast(_ json: String) {
        lock.lock(); let peers = Array(hostPeers.values); lock.unlock(); peers.forEach { $0.send(json) }
    }

    func send(toPeer token: String, json: String) {
        lock.lock(); let peer = hostPeers[token]; lock.unlock(); peer?.send(json)
    }

    func dropPeer(_ token: String) {
        lock.lock(); let peer = hostPeers.removeValue(forKey: token); lock.unlock(); peer?.close()
    }

    func stopDiscovery() {
        lock.lock()
        discoveryRunning = false
        let fd = clientDiscoveryFD
        clientDiscoveryFD = -1
        lock.unlock()
        if fd >= 0 { shutdown(fd, SHUT_RDWR); Darwin.close(fd) }
    }

    private func closeClientOnly() {
        lock.lock(); let peer = clientPeer; clientPeer = nil; lock.unlock(); peer?.close()
    }

    func closeAll() {
        lock.lock()
        generation &+= 1
        discoveryRunning = false
        let listen = tcpListenFD; tcpListenFD = -1
        let hostUDP = hostDiscoveryFD; hostDiscoveryFD = -1
        let clientUDP = clientDiscoveryFD; clientDiscoveryFD = -1
        let client = clientPeer; clientPeer = nil
        let peers = Array(hostPeers.values); hostPeers.removeAll(); discovered.removeAll()
        lock.unlock()
        for fd in [listen, hostUDP, clientUDP] where fd >= 0 { shutdown(fd, SHUT_RDWR); Darwin.close(fd) }
        client?.close(); peers.forEach { $0.close() }
    }

    private func isCurrent(_ gen: UInt64) -> Bool { lock.lock(); defer { lock.unlock() }; return generation == gen }
    private func discoveryIsRunning(_ gen: UInt64) -> Bool { lock.lock(); defer { lock.unlock() }; return generation == gen && discoveryRunning }

    private func sanitizeName(_ value: String) -> String {
        let clean = value.replacingOccurrences(of: "|", with: " ").replacingOccurrences(of: "\n", with: " ").replacingOccurrences(of: "\r", with: " ").trimmingCharacters(in: .whitespacesAndNewlines)
        return String(clean.prefix(36))
    }

    private func emit(_ method: String, _ args: [String]) { onEvent?(method, args) }
}

private final class Peer {
    let token: String
    private let fd: Int32
    private let onLine: (String) -> Void
    private let onClose: () -> Void
    private let writeLock = NSLock()
    private let closeLock = NSLock()
    private var closed = false

    init(token: String, fd: Int32, onLine: @escaping (String) -> Void, onClose: @escaping () -> Void) {
        self.token = token
        self.fd = fd
        self.onLine = onLine
        self.onClose = onClose
    }

    func start(on queue: DispatchQueue) {
        queue.async { [weak self] in self?.readLoop() }
    }

    func send(_ json: String) {
        let safe = json.replacingOccurrences(of: "\r", with: "").replacingOccurrences(of: "\n", with: "")
        guard safe.count <= NearbyNetworking.maxMessageChars else { return }
        let data = Array((safe + "\n").utf8)
        writeLock.lock(); defer { writeLock.unlock() }
        guard !isClosed else { return }
        var sent = 0
        while sent < data.count {
            let n = data.withUnsafeBytes { raw -> Int in
                guard let base = raw.baseAddress else { return -1 }
                return Darwin.send(fd, base.advanced(by: sent), data.count - sent, 0)
            }
            if n <= 0 { close(); return }
            sent += n
        }
    }

    private func readLoop() {
        var buffer = [UInt8](repeating: 0, count: 4096)
        var pending = Data()
        while !isClosed {
            let n = recv(fd, &buffer, buffer.count, 0)
            if n <= 0 { break }
            pending.append(contentsOf: buffer[0..<n])
            if pending.count > NearbyNetworking.maxMessageChars * 2 { break }
            while let newline = pending.firstIndex(of: 10) {
                let lineData = pending[..<newline]
                pending.removeSubrange(...newline)
                if lineData.count > NearbyNetworking.maxMessageChars { close(); return }
                if let line = String(data: lineData, encoding: .utf8), !line.isEmpty { onLine(line) }
            }
        }
        close()
    }

    private var isClosed: Bool { closeLock.lock(); defer { closeLock.unlock() }; return closed }

    func close() {
        closeLock.lock()
        if closed { closeLock.unlock(); return }
        closed = true
        closeLock.unlock()
        shutdown(fd, SHUT_RDWR)
        Darwin.close(fd)
        onClose()
    }
}
