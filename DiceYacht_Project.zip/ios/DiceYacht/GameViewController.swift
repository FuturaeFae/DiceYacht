import UIKit
import WebKit

final class GameViewController: UIViewController, WKScriptMessageHandler, WKNavigationDelegate, WKUIDelegate {
    private var webView: WKWebView!
    private let nearby = NearbyNetworking()

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor(red: 3/255, green: 40/255, blue: 60/255, alpha: 1)

        let content = WKUserContentController()
        content.add(self, name: "diceYacht")
        content.addUserScript(WKUserScript(source: Self.bridgeScript, injectionTime: .atDocumentStart, forMainFrameOnly: true))

        let config = WKWebViewConfiguration()
        config.userContentController = content
        config.defaultWebpagePreferences.allowsContentJavaScript = true
        config.websiteDataStore = .default()

        webView = WKWebView(frame: .zero, configuration: config)
        webView.translatesAutoresizingMaskIntoConstraints = false
        webView.navigationDelegate = self
        webView.uiDelegate = self
        webView.scrollView.bounces = false
        webView.isOpaque = false
        webView.backgroundColor = view.backgroundColor
        view.addSubview(webView)
        NSLayoutConstraint.activate([
            webView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            webView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            webView.topAnchor.constraint(equalTo: view.topAnchor),
            webView.bottomAnchor.constraint(equalTo: view.bottomAnchor)
        ])

        nearby.onEvent = { [weak self] method, args in
            self?.emitJS(method: method, args: args)
        }

        guard let assets = Bundle.main.resourceURL?.appendingPathComponent("GameAssets", isDirectory: true),
              FileManager.default.fileExists(atPath: assets.appendingPathComponent("index.html").path) else {
            showStartupError("Game assets are missing from this build.")
            return
        }
        let index = assets.appendingPathComponent("index.html")
        webView.loadFileURL(index, allowingReadAccessTo: assets)
    }

    deinit {
        nearby.closeAll()
        webView?.configuration.userContentController.removeScriptMessageHandler(forName: "diceYacht")
    }

    func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
        guard message.name == "diceYacht",
              let body = message.body as? [String: Any],
              let method = body["method"] as? String else { return }
        let args = body["args"] as? [Any] ?? []

        switch method {
        case "setTextZoom":
            let percent = clampInt(args.first, min: 80, max: 140, fallback: 100)
            let scale = Double(percent) / 100.0
            webView.evaluateJavaScript("document.documentElement.style.setProperty('--text-scale','\(scale)')")
        case "vibrate":
            let ms = clampInt(args.first, min: 1, max: 80, fallback: 12)
            let style: UIImpactFeedbackGenerator.FeedbackStyle = ms >= 22 ? .medium : .light
            let generator = UIImpactFeedbackGenerator(style: style)
            generator.prepare()
            generator.impactOccurred(intensity: ms >= 22 ? 0.8 : 0.45)
        case "nearbyStartHost":
            nearby.startHost(displayName: stringArg(args, 0))
            UIApplication.shared.isIdleTimerDisabled = true
        case "nearbyStartDiscovery":
            nearby.startDiscovery()
        case "nearbyStopDiscovery":
            nearby.stopDiscovery()
        case "nearbyConnect":
            nearby.connect(serviceId: stringArg(args, 0))
            UIApplication.shared.isIdleTimerDisabled = true
        case "nearbySend":
            nearby.sendToHost(stringArg(args, 0))
        case "nearbyBroadcast":
            nearby.broadcast(stringArg(args, 0))
        case "nearbySendTo":
            nearby.send(toPeer: stringArg(args, 0), json: stringArg(args, 1))
        case "nearbyDropPeer":
            nearby.dropPeer(stringArg(args, 0))
        case "nearbyClose":
            nearby.closeAll()
            UIApplication.shared.isIdleTimerDisabled = false
        default:
            break
        }
    }

    private func emitJS(method: String, args: [String]) {
        DispatchQueue.main.async { [weak self] in
            guard let self else { return }
            let encoded: [String] = args.map { value in
                guard let data = try? JSONSerialization.data(withJSONObject: [value]),
                      let array = String(data: data, encoding: .utf8),
                      array.count >= 2 else { return "\"\"" }
                return String(array.dropFirst().dropLast())
            }
            let js = "window.DiceYachtNative&&window.DiceYachtNative.\(method)(\(encoded.joined(separator: ",")))"
            self.webView.evaluateJavaScript(js)
        }
    }

    private func showStartupError(_ message: String) {
        let label = UILabel()
        label.text = "Dice Yacht could not start.\n\n\(message)"
        label.numberOfLines = 0
        label.textAlignment = .center
        label.textColor = .white
        label.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(label)
        NSLayoutConstraint.activate([
            label.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 30),
            label.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -30),
            label.centerYAnchor.constraint(equalTo: view.centerYAnchor)
        ])
    }

    private func clampInt(_ value: Any?, min low: Int, max high: Int, fallback: Int) -> Int {
        let n: Int
        if let i = value as? Int { n = i }
        else if let d = value as? Double { n = Int(d) }
        else if let s = value as? String, let i = Int(s) { n = i }
        else { n = fallback }
        return Swift.max(low, Swift.min(high, n))
    }

    private func stringArg(_ args: [Any], _ index: Int) -> String {
        guard index >= 0, index < args.count else { return "" }
        return args[index] as? String ?? String(describing: args[index])
    }

    private static let bridgeScript = #"""
    (() => {
      const post = (method, args=[]) => {
        try { window.webkit.messageHandlers.diceYacht.postMessage({method, args}); } catch (_) {}
      };
      window.Android = {
        setTextZoom: p => post('setTextZoom', [p]),
        vibrate: ms => post('vibrate', [ms]),
        nearbyStartHost: name => post('nearbyStartHost', [name]),
        nearbyStartDiscovery: () => post('nearbyStartDiscovery'),
        nearbyStopDiscovery: () => post('nearbyStopDiscovery'),
        nearbyConnect: id => post('nearbyConnect', [id]),
        nearbySend: json => post('nearbySend', [json]),
        nearbyBroadcast: json => post('nearbyBroadcast', [json]),
        nearbySendTo: (token, json) => post('nearbySendTo', [token, json]),
        nearbyDropPeer: token => post('nearbyDropPeer', [token]),
        nearbyClose: () => post('nearbyClose')
      };
      window.DiceYachtPlatform = 'ios';
    })();
    """#
}
