Dice Yacht official Android build payload

This ZIP is meant to be uploaded to the root of a GitHub repository as DiceYacht_Project.zip.
Do not extract it on GitHub. The accompanying GitHub Actions workflow extracts it on the build server and compiles the Android APK with the official Android Gradle toolchain.

Build: 1.0.4
compileSdk/targetSdk: 35
minSdk: 24
