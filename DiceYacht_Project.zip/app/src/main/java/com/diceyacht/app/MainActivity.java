package com.diceyacht.app;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Build;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.view.Gravity;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebChromeClient;
import android.webkit.JavascriptInterface;
import android.webkit.WebViewClient;
import android.widget.TextView;

public class MainActivity extends Activity {
    private WebView webView;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try {
            openGame();
        } catch (Throwable t) {
            showStartupError(t);
        }
    }

    private void openGame() {
        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(3, 40, 60));

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);

        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        webView.addJavascriptInterface(new AndroidBridge(), "Android");
        setContentView(webView);
        webView.loadUrl("file:///android_asset/index.html");
    }

    private class AndroidBridge {
        @JavascriptInterface
        public void setTextZoom(final int percent) {
            final int safePercent = Math.max(80, Math.min(140, percent));
            runOnUiThread(() -> {
                if (webView != null) {
                    webView.getSettings().setTextZoom(safePercent);
                }
            });
        }

        @JavascriptInterface
        public void vibrate(final int milliseconds) {
            final int duration = Math.max(1, Math.min(80, milliseconds));
            runOnUiThread(() -> {
                try {
                    Vibrator vibrator = (Vibrator) getSystemService(VIBRATOR_SERVICE);
                    if (vibrator == null || !vibrator.hasVibrator()) return;
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                        vibrator.vibrate(VibrationEffect.createOneShot(duration, VibrationEffect.DEFAULT_AMPLITUDE));
                    } else {
                        vibrator.vibrate(duration);
                    }
                } catch (Throwable ignored) { }
            });
        }
    }

    private void showStartupError(Throwable t) {
        TextView error = new TextView(this);
        error.setTextColor(Color.WHITE);
        error.setBackgroundColor(Color.rgb(3, 40, 60));
        error.setGravity(Gravity.CENTER);
        error.setPadding(36, 36, 36, 36);
        error.setText("Dice Yacht could not start.\n\n" + t.getClass().getSimpleName() + ": " + String.valueOf(t.getMessage()));
        setContentView(error);
    }

    @Override
    public void onBackPressed() {
        if (webView == null) {
            super.onBackPressed();
            return;
        }
        webView.evaluateJavascript(
            "window.handleAndroidBack ? window.handleAndroidBack() : false",
            value -> {
                boolean handled = "true".equals(value);
                if (!handled) {
                    MainActivity.this.finish();
                }
            }
        );
    }

    @Override
    protected void onDestroy() {
        if (webView != null) {
            webView.stopLoading();
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }
}
