package com.diceyacht.app;

import android.app.Activity;
import android.graphics.Color;
import android.net.DhcpInfo;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.Bundle;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.view.Gravity;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.TextView;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketException;
import java.net.SocketTimeoutException;
import java.nio.charset.StandardCharsets;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;

public class MainActivity extends Activity {
    private static final int DISCOVERY_PORT = 45831;
    private static final String DISCOVER_REQUEST = "DICEYACHT_DISCOVER_V1";
    private static final String DISCOVER_RESPONSE = "DICEYACHT_HOST_V1|";
    private static final int MAX_MESSAGE_CHARS = 65536;

    private WebView webView;
    private final ExecutorService networkExecutor = Executors.newCachedThreadPool();
    private final Map<String, ClientPeer> hostPeers = new ConcurrentHashMap<>();
    private final Map<String, InetSocketAddress> discoveredHosts = new ConcurrentHashMap<>();

    private volatile ServerSocket nearbyServer;
    private volatile DatagramSocket hostDiscoverySocket;
    private volatile DatagramSocket clientDiscoverySocket;
    private volatile Socket nearbyClientSocket;
    private volatile ClientPeer nearbyClientPeer;
    private final AtomicBoolean discoveryRunning = new AtomicBoolean(false);
    private volatile String hostedDisplayName = "Dice Yacht Game";

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try {
            openGame();
        } catch (Throwable t) {
            showStartupError(t);
        }
    }

    private void openGame() {
        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(3, 40, 60));

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);

        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        webView.addJavascriptInterface(new AndroidBridge(), "Android");
        setContentView(webView);
        webView.loadUrl("file:///android_asset/index.html");
    }

    private class AndroidBridge {
        @JavascriptInterface
        public void setTextZoom(final int percent) {
            final int safePercent = Math.max(80, Math.min(140, percent));
            runOnUiThread(() -> {
                if (webView != null) webView.getSettings().setTextZoom(safePercent);
            });
        }

        @JavascriptInterface
        public void vibrate(final int milliseconds) {
            final int duration = Math.max(1, Math.min(80, milliseconds));
            runOnUiThread(() -> {
                try {
                    Vibrator vibrator = (Vibrator) getSystemService(VIBRATOR_SERVICE);
                    if (vibrator == null || !vibrator.hasVibrator()) return;
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                        vibrator.vibrate(VibrationEffect.createOneShot(duration, VibrationEffect.DEFAULT_AMPLITUDE));
                    } else {
                        vibrator.vibrate(duration);
                    }
                } catch (Throwable ignored) { }
            });
        }

        @JavascriptInterface
        public void nearbyStartHost(final String displayName) {
            startNearbyHost(displayName);
        }

        @JavascriptInterface
        public void nearbyStartDiscovery() {
            startNearbyDiscovery();
        }

        @JavascriptInterface
        public void nearbyStopDiscovery() {
            stopNearbyDiscovery();
        }

        @JavascriptInterface
        public void nearbyConnect(final String serviceId) {
            connectToNearbyHost(serviceId);
        }

        @JavascriptInterface
        public void nearbySend(final String json) {
            ClientPeer peer = nearbyClientPeer;
            if (peer != null) peer.send(json);
        }

        @JavascriptInterface
        public void nearbyBroadcast(final String json) {
            broadcastToNearbyClients(json);
        }

        @JavascriptInterface
        public void nearbySendTo(final String peerToken, final String json) {
            ClientPeer peer = hostPeers.get(peerToken);
            if (peer != null) peer.send(json);
        }

        @JavascriptInterface
        public void nearbyDropPeer(final String peerToken) {
            ClientPeer peer = hostPeers.remove(peerToken);
            if (peer != null) peer.close();
        }

        @JavascriptInterface
        public void nearbyClose() {
            closeNearbyNetworking();
        }
    }

    private void startNearbyHost(String requestedName) {
        closeNearbyNetworking();
        String safeName = sanitizeDiscoveryName(requestedName);
        hostedDisplayName = safeName.isEmpty() ? "Dice Yacht Game" : safeName + "'s Game";

        networkExecutor.execute(() -> {
            try {
                ServerSocket server = new ServerSocket();
                server.setReuseAddress(true);
                server.bind(new InetSocketAddress(0));
                nearbyServer = server;
                startHostDiscoveryResponder(server.getLocalPort());
                emitJs("onHostReady", hostedDisplayName);

                while (!server.isClosed()) {
                    Socket socket = server.accept();
                    socket.setTcpNoDelay(true);
                    socket.setKeepAlive(true);
                    String token = UUID.randomUUID().toString();
                    ClientPeer peer = new ClientPeer(token, socket, true);
                    hostPeers.put(token, peer);
                    emitJs("onPeerConnected", token);
                    networkExecutor.execute(peer::readLoop);
                }
            } catch (SocketException ignored) {
                // Normal when hosting is stopped.
            } catch (Throwable t) {
                emitJs("onNearbyError", "Could not host nearby game: " + safeMessage(t));
                closeNearbyNetworking();
            }
        });
    }

    private void startHostDiscoveryResponder(final int tcpPort) {
        networkExecutor.execute(() -> {
            try {
                DatagramSocket socket = new DatagramSocket(null);
                socket.setReuseAddress(true);
                socket.setBroadcast(true);
                socket.bind(new InetSocketAddress(DISCOVERY_PORT));
                hostDiscoverySocket = socket;
                byte[] buffer = new byte[512];

                while (!socket.isClosed()) {
                    DatagramPacket packet = new DatagramPacket(buffer, buffer.length);
                    socket.receive(packet);
                    String request = new String(packet.getData(), packet.getOffset(), packet.getLength(), StandardCharsets.UTF_8);
                    if (!DISCOVER_REQUEST.equals(request)) continue;

                    String responseText = DISCOVER_RESPONSE + tcpPort + "|" + sanitizeDiscoveryName(hostedDisplayName);
                    byte[] response = responseText.getBytes(StandardCharsets.UTF_8);
                    DatagramPacket reply = new DatagramPacket(response, response.length, packet.getAddress(), packet.getPort());
                    socket.send(reply);
                }
            } catch (SocketException ignored) {
                // Normal when hosting is stopped.
            } catch (Throwable t) {
                if (nearbyServer != null && !nearbyServer.isClosed()) {
                    emitJs("onNearbyError", "Nearby discovery stopped: " + safeMessage(t));
                }
            }
        });
    }

    private void startNearbyDiscovery() {
        stopNearbyDiscovery();
        discoveredHosts.clear();
        discoveryRunning.set(true);
        emitJs("onDiscoveryStarted");

        networkExecutor.execute(() -> {
            DatagramSocket socket = null;
            try {
                socket = new DatagramSocket();
                socket.setBroadcast(true);
                socket.setSoTimeout(350);
                clientDiscoverySocket = socket;
                byte[] request = DISCOVER_REQUEST.getBytes(StandardCharsets.UTF_8);
                long lastSend = 0L;
                byte[] receiveBuffer = new byte[1024];

                while (discoveryRunning.get() && !socket.isClosed()) {
                    long now = System.currentTimeMillis();
                    if (now - lastSend >= 900L) {
                        sendDiscoveryPacket(socket, request, InetAddress.getByName("255.255.255.255"));
                        InetAddress localBroadcast = getWifiBroadcastAddress();
                        if (localBroadcast != null && !"255.255.255.255".equals(localBroadcast.getHostAddress())) {
                            sendDiscoveryPacket(socket, request, localBroadcast);
                        }
                        lastSend = now;
                    }

                    try {
                        DatagramPacket response = new DatagramPacket(receiveBuffer, receiveBuffer.length);
                        socket.receive(response);
                        handleDiscoveryResponse(response);
                    } catch (SocketTimeoutException ignored) {
                        // Continue scanning.
                    }
                }
            } catch (SocketException ignored) {
                // Normal when discovery is stopped.
            } catch (Throwable t) {
                if (discoveryRunning.get()) emitJs("onNearbyError", "Could not search nearby: " + safeMessage(t));
            } finally {
                if (socket != null && !socket.isClosed()) socket.close();
                if (clientDiscoverySocket == socket) clientDiscoverySocket = null;
            }
        });
    }

    private void sendDiscoveryPacket(DatagramSocket socket, byte[] request, InetAddress address) {
        try {
            DatagramPacket packet = new DatagramPacket(request, request.length, address, DISCOVERY_PORT);
            socket.send(packet);
        } catch (Throwable ignored) { }
    }

    private void handleDiscoveryResponse(DatagramPacket packet) {
        try {
            String text = new String(packet.getData(), packet.getOffset(), packet.getLength(), StandardCharsets.UTF_8);
            if (!text.startsWith(DISCOVER_RESPONSE)) return;
            String rest = text.substring(DISCOVER_RESPONSE.length());
            int split = rest.indexOf('|');
            if (split <= 0) return;
            int port = Integer.parseInt(rest.substring(0, split));
            if (port < 1 || port > 65535) return;
            String name = sanitizeDiscoveryName(rest.substring(split + 1));
            if (name.isEmpty()) name = "Dice Yacht Game";
            String host = packet.getAddress().getHostAddress();
            String serviceId = host + ":" + port;
            discoveredHosts.put(serviceId, new InetSocketAddress(packet.getAddress(), port));
            emitJs("onServiceFound", serviceId, name);
        } catch (Throwable ignored) { }
    }

    private InetAddress getWifiBroadcastAddress() {
        try {
            WifiManager wifi = (WifiManager) getApplicationContext().getSystemService(WIFI_SERVICE);
            if (wifi == null) return null;
            DhcpInfo dhcp = wifi.getDhcpInfo();
            if (dhcp == null || dhcp.netmask == 0) return null;
            int broadcast = (dhcp.ipAddress & dhcp.netmask) | ~dhcp.netmask;
            byte[] quads = new byte[4];
            for (int k = 0; k < 4; k++) quads[k] = (byte) ((broadcast >> (k * 8)) & 0xFF);
            return InetAddress.getByAddress(quads);
        } catch (Throwable ignored) {
            return null;
        }
    }

    private void stopNearbyDiscovery() {
        discoveryRunning.set(false);
        DatagramSocket socket = clientDiscoverySocket;
        clientDiscoverySocket = null;
        if (socket != null) socket.close();
    }

    private void connectToNearbyHost(final String serviceId) {
        InetSocketAddress address = discoveredHosts.get(serviceId);
        if (address == null) {
            emitJs("onNearbyError", "That nearby game is no longer available. Search again.");
            return;
        }
        stopNearbyDiscovery();
        closeNearbyClientOnly();

        networkExecutor.execute(() -> {
            try {
                Socket socket = new Socket();
                socket.connect(address, 5000);
                socket.setTcpNoDelay(true);
                socket.setKeepAlive(true);
                nearbyClientSocket = socket;
                ClientPeer peer = new ClientPeer("host", socket, false);
                nearbyClientPeer = peer;
                emitJs("onClientConnected", serviceId);
                peer.readLoop();
            } catch (Throwable t) {
                emitJs("onNearbyError", "Could not join nearby game: " + safeMessage(t));
                closeNearbyClientOnly();
            }
        });
    }

    private void broadcastToNearbyClients(String json) {
        for (ClientPeer peer : hostPeers.values()) peer.send(json);
    }

    private class ClientPeer {
        private final String token;
        private final Socket socket;
        private final boolean incomingToHost;
        private final BufferedReader reader;
        private final BufferedWriter writer;
        private final Object writeLock = new Object();
        private final AtomicBoolean closed = new AtomicBoolean(false);

        ClientPeer(String token, Socket socket, boolean incomingToHost) throws IOException {
            this.token = token;
            this.socket = socket;
            this.incomingToHost = incomingToHost;
            this.reader = new BufferedReader(new InputStreamReader(socket.getInputStream(), StandardCharsets.UTF_8));
            this.writer = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream(), StandardCharsets.UTF_8));
        }

        void readLoop() {
            try {
                String line;
                while (!closed.get() && (line = readLimitedLine(reader)) != null) {
                    if (line.isEmpty()) continue;
                    if (incomingToHost) emitJs("onMessage", token, line);
                    else emitJs("onMessage", "", line);
                }
            } catch (Throwable ignored) {
                // Disconnect path below handles UI state.
            } finally {
                close();
                if (incomingToHost) {
                    hostPeers.remove(token, this);
                    emitJs("onPeerDisconnected", token);
                } else {
                    if (nearbyClientPeer == this) nearbyClientPeer = null;
                    if (nearbyClientSocket == socket) nearbyClientSocket = null;
                    emitJs("onClientDisconnected");
                }
            }
        }

        void send(String json) {
            if (json == null || closed.get()) return;
            String safe = json.replace("\r", "").replace("\n", "");
            if (safe.length() > MAX_MESSAGE_CHARS) return;
            synchronized (writeLock) {
                if (closed.get()) return;
                try {
                    writer.write(safe);
                    writer.write('\n');
                    writer.flush();
                } catch (Throwable ignored) {
                    close();
                }
            }
        }

        void close() {
            if (!closed.compareAndSet(false, true)) return;
            try { socket.close(); } catch (Throwable ignored) { }
        }
    }

    private String readLimitedLine(BufferedReader reader) throws IOException {
        StringBuilder out = new StringBuilder();
        int ch;
        while ((ch = reader.read()) != -1) {
            if (ch == '\n') return out.toString();
            if (ch == '\r') continue;
            if (out.length() >= MAX_MESSAGE_CHARS) throw new IOException("Nearby message too large");
            out.append((char) ch);
        }
        return out.length() == 0 ? null : out.toString();
    }

    private void closeNearbyClientOnly() {
        ClientPeer peer = nearbyClientPeer;
        nearbyClientPeer = null;
        if (peer != null) peer.close();
        Socket socket = nearbyClientSocket;
        nearbyClientSocket = null;
        if (socket != null) try { socket.close(); } catch (Throwable ignored) { }
    }

    private synchronized void closeNearbyNetworking() {
        stopNearbyDiscovery();
        closeNearbyClientOnly();

        DatagramSocket responder = hostDiscoverySocket;
        hostDiscoverySocket = null;
        if (responder != null) responder.close();

        ServerSocket server = nearbyServer;
        nearbyServer = null;
        if (server != null) try { server.close(); } catch (Throwable ignored) { }

        for (ClientPeer peer : hostPeers.values()) peer.close();
        hostPeers.clear();
        discoveredHosts.clear();
    }

    private String sanitizeDiscoveryName(String value) {
        if (value == null) return "";
        String clean = value.replace('|', ' ').replace('\n', ' ').replace('\r', ' ').trim();
        return clean.length() > 36 ? clean.substring(0, 36) : clean;
    }

    private String safeMessage(Throwable t) {
        if (t == null || t.getMessage() == null || t.getMessage().trim().isEmpty()) return "network error";
        String value = t.getMessage().trim();
        return value.length() > 120 ? value.substring(0, 120) : value;
    }

    private void emitJs(String method, String... args) {
        StringBuilder js = new StringBuilder("window.DiceYachtNative&&window.DiceYachtNative.");
        js.append(method).append('(');
        for (int i = 0; i < args.length; i++) {
            if (i > 0) js.append(',');
            js.append(JSONObject.quote(args[i] == null ? "" : args[i]));
        }
        js.append(")");
        runOnUiThread(() -> {
            if (webView != null) webView.evaluateJavascript(js.toString(), null);
        });
    }

    private void showStartupError(Throwable t) {
        TextView error = new TextView(this);
        error.setTextColor(Color.WHITE);
        error.setBackgroundColor(Color.rgb(3, 40, 60));
        error.setGravity(Gravity.CENTER);
        error.setPadding(36, 36, 36, 36);
        error.setText("Dice Yacht could not start.\n\n" + t.getClass().getSimpleName() + ": " + String.valueOf(t.getMessage()));
        setContentView(error);
    }

    @Override
    public void onBackPressed() {
        if (webView == null) {
            super.onBackPressed();
            return;
        }
        webView.evaluateJavascript(
            "window.handleAndroidBack ? window.handleAndroidBack() : false",
            value -> {
                boolean handled = "true".equals(value);
                if (!handled) MainActivity.this.finish();
            }
        );
    }

    @Override
    protected void onDestroy() {
        closeNearbyNetworking();
        networkExecutor.shutdownNow();
        if (webView != null) {
            webView.stopLoading();
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }
}
