# Dice Yacht publishing guide

**Publisher:** Fae Creative by Futurae  
**Independent creator:** Futurae  
**Support & business:** futuraefae@gmail.com

Dice Yacht v1.8.0 contains both an Android project and an iOS 15+ project using the same bundled HTML/JS game and the same Nearby Multiplayer protocol. This checklist is operational guidance, not jurisdiction-specific legal advice.

## Android

1. Keep the Android signing key permanently backed up.
2. Configure the four Dice Yacht Android signing secrets in GitHub Actions before distributing paid/public APK updates.
3. Build the release APK with the reusable Android workflow.
4. Test installation and updating over the prior signed release.
5. Test Nearby Multiplayer on at least two physical phones.

## iPhone / iPad

Apple requires code signing for physical iPhones and iPads. The iOS source is in `ios/` and is generated with XcodeGen from `ios/project.yml`.

For development/testing on physical iPhones, Apple requires an App ID, signing certificate, and provisioning profile. For Ad Hoc distribution, each recipient device must be registered in the Apple Developer account. For broad public distribution, use an Apple-supported public distribution route such as App Store Connect/TestFlight/App Store.

The included iOS validation workflow builds the app without signing to catch compile problems. A separate signed iOS release workflow can be used once Apple signing credentials/provisioning are configured.

Recommended bundle identifier: `com.faecreative.diceyacht`.

Before an iOS release:

1. Enroll/maintain the appropriate Apple Developer account.
2. Register the Dice Yacht App ID/bundle ID.
3. Configure signing/provisioning for the chosen Apple distribution method.
4. Build and test on physical iPhones, not only the simulator.
5. Accept the iOS local-network permission prompt and verify iPhone ↔ Android hosting/joining on the same Wi-Fi.
6. Verify the app icon, launch screen, privacy manifest, About & Legal screen, haptics, Back buttons, and rematch flow.

## Cross-platform Nearby Multiplayer QA

Test at least:

- Android host → Android join
- Android host → iPhone join
- iPhone host → Android join
- iPhone host → iPhone join
- 3+ mixed devices
- live held-dice synchronization
- spectator turn banner and locked controls
- score synchronization
- disconnect during a turn
- synchronized Play Again ready-up/rematch
- same Wi-Fi and any hotspot setup you intend to advertise as supported

## Commercial release checklist

Review `PRIVACY_POLICY.txt`, `TERMS_OF_USE.txt`, and `THIRD_PARTY_NOTICES.txt`. Confirm publisher/contact details are current. Keep signing credentials private and backed up. Perform final trademark/legal review appropriate to your jurisdiction and sales channel.
