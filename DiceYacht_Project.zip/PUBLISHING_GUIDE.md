# Dice Yacht publishing checklist

This project is prepared for direct Android distribution such as a paid Patreon post. This checklist is operational guidance, not jurisdiction-specific legal advice.

## Before charging for a build

1. Use a persistent release signing key. Do not publish recurring paid builds signed by a disposable debug key.
2. Back up the release keystore and its passwords in at least two secure places. Losing the signing key can prevent users from installing future updates over the version they already have.
3. Keep the source repository private if it contains any signing material. The recommended workflow keeps signing material in GitHub Actions Secrets rather than the source ZIP.
4. Publisher branding is set to **Fae Creative by Futurae**, independent creator **Futurae**, with support/privacy/business contact **futuraefae@gmail.com**. Review these details before each public release.
5. Do not market the app as an official Yahtzee product or use third-party trademarks/logos without permission. Dice Yacht uses its own name and artwork.
6. Test Nearby Multiplayer on at least two physical Android phones, including same-Wi-Fi and phone-hotspot scenarios.
7. Test upgrade installation from the previous signed release without uninstalling it.
8. Keep a copy of every released APK and note its versionCode/versionName.

## Patreon packaging

Patreon supports ZIP attachments. For a clean paid download, upload the workflow-generated `DiceYacht-Patreon.zip`, which contains the signed APK plus installation/privacy/terms files.

## Release signing secrets used by the build workflow

- `DICEYACHT_KEYSTORE_B64`
- `DICEYACHT_STORE_PASSWORD`
- `DICEYACHT_KEY_ALIAS`
- `DICEYACHT_KEY_PASSWORD`

The optional signing-key workflow can generate the values once. Save them securely, then add them as GitHub repository Actions secrets. Once all four are present, the normal reusable build workflow automatically produces a signed release APK instead of a debug test APK.


## Publisher identity

**Dice Yacht**  
A Fae Creative game  
**by Futurae**

**Developer & Publisher:** Fae Creative by Futurae  
**Independent creator:** Futurae  
**Support & business inquiries:** futuraefae@gmail.com
