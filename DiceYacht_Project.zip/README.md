# Dice Yacht — Android official-build project

This project is designed to be compiled by the official Android Gradle Plugin rather than the experimental hand-packed APK builder used by earlier test builds.

## Android configuration
- App: Dice Yacht
- Application ID: `com.diceyacht.game.official`
- Minimum Android: API 24 (Android 7.0)
- Target/compile SDK: API 35
- Android Gradle Plugin: 8.9.2
- Gradle: 8.11.1
- Java: 17

## Build with GitHub Actions
The included `.github/workflows/build-apk.yml` installs the official Android SDK 35 and runs `:app:assembleDebug`.
The resulting `app-debug.apk` is a normal Gradle-built, debug-signed APK suitable for sideload testing on Android/Samsung devices.

## Game features
- Nautical Dice Yacht UI
- Animated 3D dice
- Roll-state scoring lock and double-action guards
- Split Upper / Lower scorecard
- 63-point upper threshold and 35-point bonus
- Yacht bonus/Joker-style handling
- 1–6 players
- Solo offline play with autosave/stats
- LAN peer-to-peer mode
- Online WebSocket multiplayer backend in `online-server/`
- No ads

## Online server
`online-server/` contains the Node.js WebSocket service. Deploy it separately and enter its `wss://...` endpoint in the app Settings screen.
