# Dice Yacht

**A Fae Creative game by Futurae**  
Developer & Publisher: **Fae Creative by Futurae**  
Support & business inquiries: **futuraefae@gmail.com**

Dice Yacht v1.8.0 is a no-server, nearby multiplayer five-dice score game for **Android 7+** and **iOS/iPadOS 15+**.

## Platforms

- `app/` — Android application project (Samsung and other Android devices)
- `ios/` — iPhone/iPad application project, generated with XcodeGen from `ios/project.yml`
- Both wrappers bundle the same game assets and use the same Nearby Multiplayer discovery/message protocol.

## Nearby Multiplayer

One phone hosts the authoritative match and other phones discover it on the same local network. No Fae Creative-operated online game server is required. The project is designed for Android ↔ Android, iPhone ↔ iPhone, and Android ↔ iPhone nearby sessions.

Physical-device QA is required before claiming support for a specific hotspot/router combination because local-network isolation rules vary by device and network.

## Building

Use `DiceYacht_Build_Workflow.yml` for Android. Use `DiceYacht_iOS_Build_Workflow.yml` for iOS compile validation and, once Apple signing credentials are configured, a signed IPA/archive export.

Apple requires code signing/provisioning for physical iPhone installation. See `PUBLISHING_GUIDE.md` and `INSTALL_AND_SUPPORT.txt`.
