# Dice Yacht — Android official-build project

This project is designed to be compiled by the official Android Gradle Plugin rather than the experimental hand-packed APK builder used by earlier test builds.

## Android configuration
- App: Dice Yacht
- Application ID: `com.diceyacht.game.official`
- Minimum Android: API 24 (Android 7.0)
- Target/compile SDK: API 35
- Android Gradle Plugin: 8.9.2
- Gradle: 8.11.1
- Java: 17

## Build with GitHub Actions
The included `.github/workflows/build-apk.yml` installs the official Android SDK 35 and runs `:app:assembleDebug`.
The resulting `app-debug.apk` is a normal Gradle-built, debug-signed APK suitable for sideload testing on Android/Samsung devices.

## Game features
- Nautical Dice Yacht UI
- Animated 3D dice
- Roll-state scoring lock and double-action guards
- Split Upper / Lower scorecard
- 63-point upper threshold and 35-point bonus
- Yacht bonus/Joker-style handling
- 1–6 players
- Solo offline play with autosave/stats
- LAN peer-to-peer mode
- Online WebSocket multiplayer backend in `online-server/`
- No ads

## Online server
`online-server/` contains the Node.js WebSocket service. Deploy it separately and enter its `wss://...` endpoint in the app Settings screen.


## v1.0.5 fixes
- clickable whole score rows and larger score boxes
- in-app menu with Exit Game
- in-app confirmation modal (no reliance on browser confirm dialogs)
- history/back-screen support for Android back button
- more compatible CSS 3D dice rendering
- held dice persist between rolls until scored or released
- WebChromeClient enabled for Android WebView dialogs

- v1.0.6: Text Size slider (80%–140%) using native Android WebView text zoom.


## v1.0.6
- Added persistent 85%–135% text size slider in Settings
- Text size previews live while dragging
- Text scale applies across menus and scorecard while keeping dice sizing independent


## v1.0.7 fixes
- replaced fragile CSS 3D cube with Samsung-safe SVG faux-3D dice
- dice animate through random intermediate faces without disappearing
- new illustrated yacht title artwork


## v1.1.0 design refresh
- concept-art-inspired visual refresh for menus and gameplay
- prettier dice with richer shading, glow, and blue-felt tray styling
- visible Back buttons with arrow icons and text labels
- polished buttons, headers, and panels to better match the nautical concept


## v1.2.0 concept-art pass
- put real concept-art crops directly into the game screens
- removed broken external SVG icon usage in WebView and replaced with inline/text buttons
- much stronger dice tray and richer 3D dice rendering with top + side pips
- improved back buttons and in-game menu button styling


## v1.3.0 screen-and-dice rebuild
- left title screen intact
- rebuilt multiplayer / lan / online / settings / stats screens from scratch with clean native artwork cards
- removed weird concept-art crops from secondary screens
- replaced SVG dice with a new CSS 3D cube system and new tumble animation
- rebuilt the dice tray without background dice art to avoid visual clashes


## v1.4.0 dice stability pass
- removed the CSS cube dice that warped badly on Android WebView
- replaced with stable beveled single-face dice with pips, thickness, shadows and held glow
- toss/bounce roll animation no longer relies on 3D transform faces
- empty score boxes are now actually empty (removed the black square glyph)
- kept the successful v1.3 art direction


## v1.4.1
- enlarged die pips for better readability on phone screens
