# Dice Yacht — Android official-build project

Dice Yacht is built with the official Android Gradle Plugin and targets Android API 35.

## Multiplayer in v1.6.0
Nearby multiplayer is completely self-contained. No Render, Railway, GitHub server, WebSocket service, account, URL, or external hosting is required.

- One Android phone starts **Host Game** and becomes the authoritative game server.
- Other phones use **Find Nearby Game** and discover the host automatically.
- Phones communicate directly over the local network using a lightweight TCP game connection and UDP discovery.
- Use the same Wi-Fi network, or use one phone's hotspot and connect the other phones to it.
- Supports 2–6 nearby players.
- The host validates turns, roll limits, stale/duplicate actions, and scoring before broadcasting state.
- Leaving/rejoining the UI does not silently create an internet dependency.

## Other current features
- Single-player autosave and statistics
- 13-category Dice Yacht scorecard, upper bonus, Yacht bonus and Joker handling
- Three-roll limit with post-roll die selection still allowed for visual review
- Adjustable dice pip size
- Roll and landing haptics
- Optional randomized per-die landing times
- Previous-screen Android Back navigation
- Custom Dice Yacht launcher icon
- No ads

## Build
Upload the reusable `DiceYacht_Project.zip` to the GitHub repository and run the existing GitHub Actions workflow. The workflow filename does not need to change between releases.

## v1.7.2 multiplayer + publishability pass
- Nearby multiplayer now synchronizes the active player's held-dice selections to every phone.
- During multiplayer, every phone displays the active player's live scorecard and dice state; non-active phones show a prominent WATCHING banner and locked controls.
- Multiplayer Play Again is now a ready-up vote. The next match begins automatically when every connected player is ready, without rebuilding the room.
- Rematches preserve the connected player list while resetting scores, dice, holds, rounds, and duplicate-action tracking.
- Added in-app About & Legal, privacy notice, personal-use license terms, and third-party notices.
- Added adaptive launcher icon resources and disabled Android cloud backup for app-local data.
- Added optional persistent release-signing support to the reusable GitHub workflow and a one-time signing-key generator workflow.
- Signed builds can output a Patreon-ready ZIP containing the APK, install instructions, privacy notice, terms, and notices.


## v1.7.2 publisher branding
- Publisher: Fae Creative by Futurae
- Independent creator: Futurae
- Support/privacy/business contact: futuraefae@gmail.com
- About & Legal and distribution documents updated with the publisher identity.
